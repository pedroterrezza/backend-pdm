class Rotas {
  static const HOME = '/';
  static const PRODUTOS = "/tela_produtos";
}
