package com.example.pdmpedroterrezzabd

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
